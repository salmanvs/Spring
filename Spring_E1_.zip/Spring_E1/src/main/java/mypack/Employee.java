package mypack;

public class Employee {
	private int id;
	private String name, address1;
	private Address address;//Aggregation  


	public Employee() {
		System.out.println("def cons");
	}

	public Employee(int id) {
		this.id = id;
	}

	public Employee(String name) {
		this.name = name;
	}
	

	public Employee(int id, String name, String address1) {
		super();
		this.id = id;
		this.name = name;
		this.address1 = address1;
	}

	public Employee(int id, String name, String address1, Address address) {
		this.id = id;
		this.name = name;
		this.address1 =address1;
		this.address=address;
	}
	
	public Employee(int id, String name, Address address) {  
	    super();  
	    this.id = id;  
	    this.name = name;  
	    this.address = address;  
	}  

	void show() {
		System.out.println(id + " " + name + " " + address1);
		System.out.println(address.toString());
	}
}