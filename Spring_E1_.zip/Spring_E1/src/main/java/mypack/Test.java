package mypack;
import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;  
import org.springframework.core.io.Resource;  
  
public class Test {  
public static void main(String[] args) {  
	/*
	 * Resource resource=new ClassPathResource("applicationContext.xml");
	 * BeanFactory factory=new XmlBeanFactory(resource);
	 * Student student=(Student)factory.getBean("s1"); 
	 * student.displayInfo();  
	 */
	ApplicationContext context =   
		    new ClassPathXmlApplicationContext("applicationContext.xml");  
      
    Student student=(Student)context.getBean("s1");  
    student.displayInfo(); 
    
    Employee s=(Employee)context.getBean("e");  
    s.show();  
    Employee s1=(Employee)context.getBean("e1");  
    s1.show();
    
}  
}  